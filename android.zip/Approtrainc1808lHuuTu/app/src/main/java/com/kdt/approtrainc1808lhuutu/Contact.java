package com.kdt.approtrainc1808lhuutu;

import java.util.Date;

public class Contact {
    int id;
    String name;
    int isImportant;
    String date;



    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int isImportant() {
        return isImportant;
    }

    public void setImportant(int important) {
        isImportant = important;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }


}
