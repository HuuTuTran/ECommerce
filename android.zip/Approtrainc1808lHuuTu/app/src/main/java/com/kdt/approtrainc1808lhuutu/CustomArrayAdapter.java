package com.kdt.approtrainc1808lhuutu;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.kdt.approtrainc1808lhuutu.Contact;
import com.kdt.approtrainc1808lhuutu.R;

import java.util.ArrayList;

public class CustomArrayAdapter extends BaseAdapter {
    private Context mContext;
    private ArrayList<Contact> mListContact;
    @Override
    public int getCount() {
        return mListContact.size();
    }
    public CustomArrayAdapter(Context context, ArrayList contacts) {
        this.mContext = context;
        this.mListContact = contacts;
    }
    @Override
    public Contact getItem(int i) {
        return mListContact.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        View itemView = LayoutInflater.from(this.mContext).inflate(R.layout.list_item,viewGroup,false) ;
        ((TextView) itemView.findViewById(R.id.itemName)).setText(getItem(i).getName());
        ((TextView) itemView.findViewById(R.id.itemDate)).setText(getItem(i).getDate());
        return itemView;
    }
}
