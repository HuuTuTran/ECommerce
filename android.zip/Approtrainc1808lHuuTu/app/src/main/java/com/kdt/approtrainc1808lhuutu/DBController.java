package com.kdt.approtrainc1808lhuutu;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

public class DBController {
    ArrayList<Contact> rsl = new ArrayList<Contact>();
    Cursor cs;
    MyDBHelper myDBHelper;
    SQLiteDatabase sqLiteDatabase;


    public  DBController (Context context) {
        myDBHelper = new MyDBHelper(context, Contract.dbName, null, 1);
        sqLiteDatabase = myDBHelper.getWritableDatabase();
        cs = getCursor();
        Log.i("nnnn", "ccccc");
    }


    public ArrayList<Contact> getAll(){
        cs.moveToFirst();
        while(!cs.isAfterLast()){
            Contact ct = new Contact();
            ct.setId(cs.getInt(cs.getColumnIndex(Contract.id)));
            ct.setName(cs.getString(cs.getColumnIndex(Contract.Name)));
            ct.setDate(cs.getString(cs.getColumnIndex(Contract.date)));
            ct.setImportant(cs.getInt(cs.getColumnIndex(Contract.isImportant)));
            rsl.add(ct);
            cs.moveToNext();
        }

        return  rsl;
    }
    public void Add(Contact obj){
        sqLiteDatabase = myDBHelper.getWritableDatabase();
        ContentValues ctvl =new ContentValues();
        ctvl.put(Contract.Name,obj.getName());
        ctvl.put(Contract.isImportant,obj.isImportant);
        ctvl.put(Contract.date,obj.getDate());
        sqLiteDatabase.insert(Contract.tableName,null,ctvl);
        cs.moveToLast();
        int id = Integer.parseInt(cs.getString(cs.getColumnIndex(Contract.id)));
        obj.setId(id);
    }
    public Cursor getCursor(){
        sqLiteDatabase = myDBHelper.getWritableDatabase();
        cs = sqLiteDatabase.rawQuery("select * from " + Contract.tableName, null);
        return cs ;
    }

   }
