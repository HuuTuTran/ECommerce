package com.kdt.approtrainc1808lhuutu;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Adapter;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    DBController db;
    ListView contacts;
    CustomArrayAdapter adapter;
    ArrayList<Contact> _contacts;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Contact c = new Contact();
        c.setName("Aptech");
        c.setImportant(1);
        c.setDate("05/01/2021");
        contacts = (ListView) findViewById(R.id.contactslist);

        db = new DBController(this);
        db.Add(c);
        _contacts = db.getAll();
        adapter = new CustomArrayAdapter(this,_contacts);
        contacts.setAdapter(adapter);
    }
}
