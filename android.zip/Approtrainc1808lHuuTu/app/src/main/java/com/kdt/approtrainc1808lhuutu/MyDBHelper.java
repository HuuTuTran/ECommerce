package com.kdt.approtrainc1808lhuutu;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MyDBHelper extends SQLiteOpenHelper {


    public MyDBHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, null, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String query = "Create Table "+Contract.tableName+"( _id integer primary key autoincrement ,Name text,isImportant integer,Crdate text )";
        sqLiteDatabase.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        String script = "drop table if exists " +Contract.tableName;
        sqLiteDatabase.execSQL(script);
        onCreate(sqLiteDatabase);
    }
}
