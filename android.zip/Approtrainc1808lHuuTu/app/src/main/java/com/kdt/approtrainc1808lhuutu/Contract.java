package com.kdt.approtrainc1808lhuutu;

public class Contract {
    public static final String tableName = "Contacts";
    public static final  String dbName = "ContactMana.db";
    public static final  String id ="_id";
    public static final  String Name ="Name";
    public static final  String isImportant ="isImportant";
    public static final  String date ="Crdate";

}
